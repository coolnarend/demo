import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

@Component({
  selector: 'app-posts',
  template: `
  <h3>Get data</h3>
  <p><img src="../assets/img/posts-1.JPG" alt="" class="img-fluid img-thumbnail"></p>
  <p><img src="../assets/img/posts-2.JPG" alt="" class="img-fluid img-thumbnail"></p>
  <div class="example">
    <ul class="list-group">
      <li class="list-group-item"
          *ngFor="let post of posts">
          {{post.id}} : {{post.title}}
      </li>
    </ul>
  </div>

  <br>
  <hr>
  <br>

  <h3>Creating data</h3>
  <div class="example">
    <input
      (keyup.enter) = "createPost(title)"
      #title
      type="text"
      class="form-control">
    <ul class="list-group">
      <li class="list-group-item"
          *ngFor="let post of posts">
          {{post.id}} : {{post.title}}
      </li>
    </ul>
  </div>

  <br>
  <hr>
  <br>

  <h3>Updating data</h3>
  <div class="example">
    <input
      (keyup.enter) = "createPost(title)"
      #title
      type="text"
      class="form-control">
    <ul class="list-group">
      <li class="list-group-item"
          *ngFor="let post of posts">
          <button
          (click)="updatePost(post)"
          class="btn btn-default btn-sm">Update</button>
          {{post.id}} : {{post.title}}
      </li>
    </ul>
  </div>
  <br>
  <hr>
  <br>

  <h3>Deleting data</h3>
  <div class="example">
    <input
      (keyup.enter) = "createPost(title)"
      #title
      type="text"
      class="form-control">
    <ul class="list-group">
      <li class="list-group-item"
          *ngFor="let post of posts">
          <button
          (click)="deletePost(post)"
          class="btn btn-default btn-sm">Delete</button>
          {{post.id}} : {{post.title}}
      </li>
    </ul>
  </div>
  `,
  styles: []
})
export class PostsComponent implements OnInit {

  posts: any [];
  private url = 'https://jsonplaceholder.typicode.com/posts';

  constructor(private http: Http) {

  }

  ngOnInit() {
    this.http.get(this.url)
      .subscribe(response => {
        this.posts = response.json();
    });
  }

  createPost(titleInput: HTMLInputElement) {
    const post: any = { title: titleInput.value };
    titleInput.value = '';

    this.http.post(this.url, JSON.stringify(post))
        .subscribe(response => {
          post.id = response.json().id;
          this.posts.splice(0, 0, post);
          console.log(response.json());
        });
  }

  updatePost(post) {

    // this.http.patch(this.url + '/' + post.id, JSON.stringify({ isRead: true }))
    //   .subscribe(response => {
    //     console.log(response.json());
    //   });

    this.http.put(this.url + '/' + post.id, JSON.stringify(post))
    .subscribe(response => {
      console.log(response.json());
    });
  }

  deletePost(post) {
    this.http.delete(this.url + '/' + post.id)
    .subscribe(response => {
      const index = this.posts.indexOf(post);
      this.posts.splice (index, 1);
    });
  }

}
