import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-introduction',
  template: `
    <img src="../assets/img/intro.JPG" alt="Intro" class="img-fluid img-thumbnail">
    <img src="../assets/img/jason-1.JPG" alt="Json" class="img-fluid img-thumbnail">
  `,
  styles: []
})
export class IntroductionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
